const express = require("express");
const app = express();
const server = require("http").createServer(app);
const io = require("socket.io").listen(server);

server.listen(3000);

app.get("/", function (request, respons) {
    respons.sendFile(__dirname + "/index.html");
});

users = [];
connections = [];

io.sockets.on("connection", function (socket) {
    //проверка на рабоспособность
    console.log("Успешно");
    //(socket) - подключаем через массив
    connections.push(socket);

    socket.on("disconnect", function (data) {
        //indexOf(socket), 1) - находим индекс сокет и удаляем один элемент
        connections.splice(connections.indexOf(socket), 1);
        console.log("Отсоединение");
    });
    //когда вызывается "send mess", в нем "add mess" в котором передаем обьект (msg) со значение (data)
    socket.on("send mess", function (data) { //data - это параметр, текстовое значение которое вводится в поле
        //делаем отдельно (data.msg) и (data.name)
        io.sockets.emit("add mess", {msg: data.msg, name: data.name, className: data.className});
    });
});