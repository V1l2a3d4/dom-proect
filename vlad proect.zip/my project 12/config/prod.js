module.exports = {
    mongodb: {
        uri: "mongodb://test:testtest1@ds137857.mlab.com:37857/contact-book-rc",
        options: { useNewUrlParser: true }
    }
};
