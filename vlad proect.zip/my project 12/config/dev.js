module.exports = {
  mongodb: {
    uri: "mongodb://localhost:27017/hillel_dev",
    options: { useNewUrlParser: true }
  }
};
