const mongoose = require("mongoose");
const { Schema, Types } = mongoose;

// TODO: разграничить данные по user'ам

const ContactsSchema = new Schema(
  {
    name: { type: String, trim: true },
    surname: { type: String, trim: true },
    email: { type: [{ type: String, trim: true, lowercase: true }] },
    birthday: { type: Date },
    avatar: { type: Schema.Types.ObjectId, ref: "FilesModel" },
    description: { type: String },
    phones: {
      type: [
        {
          code: { type: String },
          value: { type: String }
        }
      ]
    },
    social: {
      fb: { type: String },
      insta: { type: String }
    },
      //category: { type: String, trim: true },//добавленна вручную
    //category: { type: Schema.Types.ObjectId, ref: "CategoriesModel" },//было закоментировано
    //addedBy: { type: Schema.Types.ObjectId, ref: "UsersModel" }//было закоментировано
  },
  {
      addedBy: { type: Schema.Types.ObjectId, ref: "UsersModel" },
      category: { type: Schema.Types.ObjectId, ref: "CategoriesModel" },
    collection: "ContactsCollection",
    timestamps: true
  }
);

ContactsSchema.statics = {
  getContacts: function(user) {
    return this.find({
      addedBy: user
    })
      .populate([
        {
          path: "category",
          select: "name"
        }
      ])
      .lean()
      .exec();
  },
    updateContactById: async function (id, data, initiator) {
        const doc = await this.findById({_id:id, addedBy: initiator});//.exec()
        if (!doc) {
            throw new Error("contact not found");
        }
        Object.assign(doc, data);  //Перезаписываем все
        return doc.save();
    },
    // updateContact: async function(id, data, initiator) {
  //    const doc = this.findOne({ _id: id, addedBy: initiator });
  //   if (!doc) {
  //       throw new Error("contact not found");
  //   }
  //   console.log(doc);
  //   Object.assign(doc, data);
  //   return doc.save();
  //  },
    //
    deleteContacts: async function (id) {
        const doc = await this.deleteOne({ _id: id }).exec();
        if (doc["deletedCount"] < 1) {
            throw new Error("contact not found");
        }
        return doc;
    },
    //
  addContact: function(data) {
    return this.create(data);
  }
};

module.exports = mongoose.model("ContactsModel", ContactsSchema);
