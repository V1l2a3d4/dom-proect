const contactsService = require("./contacts.service");
const setCat = require("../categories/categories.service.js");//подключили вручную

exports.getContacts = async (req, res, next) => {
  try {
    res.json({ data: await contactsService.getContacts() });
  } catch (e) {
    next(e);
  }
};

exports.updateContactById = async (req, res, next) => {
  try {
    res.json({
                                                //сдесь параметры, тело, user_id
      data: await contactsService.updateContactById(req.params.id, req.body, req.user._id)
    });
  } catch (e) {
    next(e);
  }
};

exports.addContact = async (req, res, next) => {
  try {
    //
    // req.body.addedBy = req.user._id;//передача уникально (user id) в (body)
    //     //
    // const addC = await contactsService.addContact(req.body);
    // res.json({data: addC});
    // const idContact = addC["_id"];//уникальный (id) контакта
    // const nameCat = addC["nameCategory"];// имя категории
    // const body = {
    //   name: nameCat,
    //   addedByContact: idContact
    // };
    // setCat.addCategory(body.req.user._id);
    res.json({ data: await contactsService.addContact(req.body)});//оригинал закоментировано
     } catch (e) {
    next(e);
  }
};
