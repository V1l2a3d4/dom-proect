const { Router } = require("express");
const router = Router();
const ctrl = require("./contacts.controller");
const val = require("./contacts.validation");
const { validate } = require("../middlewares");

router.get('/', ctrl.getContacts);

// TODO: add validation
router.post('/',validate(val.addContact), ctrl.addContact);
router.put('/:id',validate(val.addContact), ctrl.updateContactById);

module.exports = router;
