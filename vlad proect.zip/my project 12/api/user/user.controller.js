const userServices = require("./user.service");

exports.registerNewUser = async (req, res, next) => {
  try {
    const result = await userServices.createUser(req.body);
    res.json({
      result
    });
  } catch (e) {
    next(e);
  }
};
exports.useUpdateProfileById = async (req, res, next) => {
  try {
    const data = await userServices.getProfile(req.user._id);
    res.render("update_profile.nunjucks", {
      Data: data
    });
  } catch (e) {
    next(e);
  }
};
exports.updateProfileById = async (req, res, next) => {
  try {
    res.json({
      Data: await userServices.updateProfile(req.user._id, req.body)
    });
  } catch (e) {
    next(e);
  }
};

exports.deleteProfileById = async (req, res, next) => {
  try {
    res.json({
      data: await userServices.deleteProfile(req.user._id)
    });
    res.clearCookie("Token");
  } catch (e) {
    next(e);
  }
};

exports.getProfile = async (req, res, next) => {
  res.json(await userServices.getProfile(req.body));
};

exports.getAllUsers = async (req, res, next) => {
  try {
    res.json({ data: await userServices.getListOfUsers() });
  } catch (e) {
    next(e);
  }
};
