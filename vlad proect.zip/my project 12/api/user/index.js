const { Router } = require("express");
const router = Router();
const ctrl = require("./user.controller");
const val = require("./user.validation");
const { validate, authorizeUser } = require("../middlewares");

router.get("/all", authorizeUser, ctrl.getAllUsers);
/**
 * @api {get}/api/user/all Возвращает профили всех пользователей
 * @apiName getAllUsers
 * @apiGroup User
 
 * @apiError error Пользователь не авторизован
 
 * @apiSuccessExample {json} Response:
 *{
 *   "data": [
 *       {
 *          "Name": "Vlad",
 *          "surname" "vlad",
 *          "_id": "6d178663bb10ec50d73c4cd9",
 *          "email": "test@test.com"
 *       },
 *       {
 *          "Name": "Vitya",
 *          "surname" "Loshkin",
 *          "_id": "6d178669bb10ec50d73c4cd0",
 *          "email": "1test@test.com"
 *       }
 *   ]
 *}
 */

router.get("/register", (req, res) => {
    res.render("register.nunjucks", {
        user: req.user || {} });
});
router.post("/register", validate(val.register), ctrl.registerNewUser);
/**
 * @api {post} /api/user/register Регистрация нового пользователя
 * @apiName registerNewUser
 * @apiGroup User
 *
 * @apiParam {String} email эмэил пользователя
 * @apiParam {String} password пароль пользователя
 *
 * @apiParamExample {json} request-example:
 *  {
 *      "email": "test_1@test.com",
 *      "password": "12345678"
 *  }
 * @apiError error если такой пользователь есть
 *
 * @apiSuccessExample {json} res:
 *  {
 *      "result": {
 *          "_id": "5d15a5ec6d720117c9625abb",
 *          "email": "test_1@test.com",
 *          "password": "$3b$08$kFZWEqPtcijpOZL85APq2.OlQ4aDpqsFYFo9FCMkMiC/e3VyIIWk6",
 *          "createdAt": "2019-06-28T05:30:20.353Z",
 *          "updatedAt": "2019-06-28T05:30:20.353Z",
 *          "__v": 0
 *      }
 *  }
 */

router.get("/profile", (req, res) => {
    res.render("profile.nunjucks", {});
});
router.post("/profile", authorizeUser, ctrl.getProfile);
/**
 * @api {get} /api/users/profile профиль пользователя
 * @apiName getProfile
 * @apiGroup Users
 * *  {
 *      "email": "test_1@test.com",
 *      "password": "12345678",
 *  }
 */
router.get("/update", authorizeUser, ctrl.useUpdateProfileById);
/**
 * @api {put} /api/user/update Обновить профиль пользователя
 * @apiName updateProfile
 * @apiGroup UserProfile
 *
 * @apiParam {String} name Имя пользователя
 * @apiParam {String} surname Фамилия пользователя
 * @apiParam {String} email Email пользователя
 * @apiParam {String} password Пароль пользователя
 * @apiParam {Date} birthday День рождения
 * @apiParam {Schema.Types.ObjectId} avatar аватарка
 * @apiParam {String} role Роль(admin, moderator, user)
 *
 * @apiParamExample {json} request:
 *  {
 *      "Name": "Vlad",
 *      "surname" "Viznyak",
 *      "email": "test_1@test.com",
 *      "password": "12345678",
 *      "birthday": "1986-05-01 00:00:00.000Z",
 *      "avatar": "6d15ae202766f2263c4bf190",
 *      "role": "Admin",
 *  }
 * @apiSuccess {Boolean} error если не авторизовался пользователь 
 *
 * @apiSuccessExample {json} res: *  {
 *      "result": {
 *          "_id": "5d15a5ec6d720117c9625abb",
 *          "Name": "Vlad",
 *          "surname" "Viznyak",
 *          "email": "test_1@test.com",
 *          "password": "12345678",
 *          "birthday": "1986-05-01 00:00:00.000Z",
 *          "avatar": "6d15ae202766f2263c4bf190",
 *          "role": "Admin",
 *          "createdAt": "2019-06-28T05:30:20.353Z",
 *          "updatedAt": "2019-06-28T05:30:20.353Z",
 *          "__v": 0
 *      }
 *  }
 */
router.put('/update', authorizeUser, validate(val.profile), ctrl.updateProfileById);

router.get('/delete', authorizeUser, ctrl.deleteProfileById);
/**
 * @api {get} /api/user/delete Удаляет профиль пользователя по (id)
 * @apiName deleteProfileById
 * @apiGroup User
 * @apiSuccess {Boolean} не авторизован пользователь (error)
 * @apiSuccessExample {json} Response:
 */

module.exports = router;