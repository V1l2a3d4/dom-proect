const { Router } = require("express");
const router = Router();
const { validate, authorizeUser } = require("../middlewares");
const { auth } = require("./auth.validation");
const ctrl = require("./auth.controller");
const passport = require("passport");


router.get("/", (req, res) => {
    res.render("auth.nunjucks", {
        user: req.user || {}
    });
});

router.post("/", validate(auth), passport.authenticate("local", {}), ctrl.authUser);
/**
 * @api {post} /api/auth авторизация(пользователя)
 * @apiName authUser
 * @apiGroup auth
 *
 * @apiParam {String} email(почта) пользователя
 * @apiParam {String} password(пароль) пользователя
 *
 * @apiParamExample {json} Request-Example:
 *  {
 *      "email": "test_1@test.com",
 *      "password": "12345678"
 *  }
 * @apiError error логин или пароль если неверный
 *
 * @apiSuccessExample {json} Response = отдаёт:
 *  {
 *      "result": {
 *          "_id": "6d15a6ec6d720127c9625af2",
 *          "email": "test_1@test.com",
 *          "password": "$3b$09$kFZWDqPtcijpOZL75APq1.0001aDpqsFYFo9FCMkMiC/e3VyIIWk6",
 *          "createdAt": "2019-06-27T05:30:20.353Z",
 *          "updatedAt": "2019-06-27T05:30:20.353Z",
 *          "__v": 0
 *      }
 *  }
 */

router.get("/check", authorizeUser, ctrl.checkAuth);
/**
 * @api {get} /api/auth/check проверка авторизации
 * @apiName checkAuth
 * @apiGroup auth
 *
 * @apiError error если не авторизован
 *
 * @apiSuccessExample {json} Response= отдаёт:
 *  {
 *      "result": {
 *          "_id": "6d15a6ec6d720127c9625af2",
 *          "email": "test_1@test.com",
 *          "password": "$3b$09$kFZWDqPtcijpOZL75APq1.0001aDpqsFYFo9FCMkMiC/e3VyIIWk6",
 *          "createdAt": "2019-06-27T05:30:20.353Z",
 *          "updatedAt": "2019-06-27T05:30:20.353Z",
 *          "__v": 0
 *      }
 *  }
 */

router.get("/logout", authorizeUser, ctrl.logOutUser);
/**
 * @api {get} /api/auth/logout проверка авторизации
 * @apiName logOutUser
 * @apiGroup auth
 *
 * @apiError error если не авторизован
 *
 * @apiSuccessExample {json} Response = отдаёт:
 *  {
 *         "message": "logout success"
 *  }
 */
module.exports = router;
